package com.example.cors_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorsSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorsSpringApplication.class, args);
	}

}
